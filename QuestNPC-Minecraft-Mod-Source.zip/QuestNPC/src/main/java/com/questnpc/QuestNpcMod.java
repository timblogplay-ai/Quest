package com.questnpc;

import com.mojang.logging.LogUtils;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;

@Mod(QuestNpcMod.MODID)
public class QuestNpcMod {
    public static final String MODID = "questnpc";
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final RegistryObject<Item> NPC_WAND = ITEMS.register("npc_editor", () ->
        new Item(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)) {
            @Override
            public InteractionResult use(Level level, Player player, InteractionHand hand) {
                if (!level.isClientSide) {
                    player.sendSystemMessage(Component.literal("§6QuestNPC Editor §7| §fКоманды: /questnpc help"));
                    player.sendSystemMessage(Component.literal("§e/questnpc spawn <имя> §7— создать NPC рядом"));
                    player.sendSystemMessage(Component.literal("§e/questnpc quest <цель> §7— начать квест на убийства"));
                    player.sendSystemMessage(Component.literal("§e/questnpc dialogue <текст> §7— задать реплику ближайшему NPC"));
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
        });
    public static final RegistryObject<Item> QUEST_TOKEN = ITEMS.register("quest_token", () ->
        new Item(new Item.Properties().stacksTo(64).rarity(Rarity.RARE)));

    public QuestNpcMod() {
        ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::addCreative);
        MinecraftForge.EVENT_BUS.register(this);
        LOGGER.info("QuestNPC initialized");
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(NPC_WAND);
            event.accept(QUEST_TOKEN);
        }
    }

    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("questnpc")
            .then(Commands.literal("help").executes(ctx -> {
                ctx.getSource().sendSuccess(() -> Component.literal("QuestNPC: /questnpc spawn <name> | /questnpc quest <kills> | /questnpc dialogue <text>"), false);
                return 1;
            }))
            .then(Commands.literal("spawn").then(Commands.argument("name", net.minecraft.commands.arguments.StringArgumentType.greedyString())
                .requires(s -> s.hasPermission(2))
                .executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    String name = net.minecraft.commands.arguments.StringArgumentType.getString(ctx, "name");
                    Villager npc = EntityType.VILLAGER.create(player.serverLevel());
                    if (npc == null) return 0;
                    npc.moveTo(player.getX() + 1.5, player.getY(), player.getZ(), player.getYRot(), 0);
                    npc.setCustomName(Component.literal(name));
                    npc.setCustomNameVisible(true);
                    npc.setPersistenceRequired();
                    player.serverLevel().addFreshEntity(npc);
                    ctx.getSource().sendSuccess(() -> Component.literal("NPC создан: " + name), false);
                    return 1;
                })))
            .then(Commands.literal("quest").then(Commands.argument("kills", net.minecraft.commands.arguments.IntegerArgumentType.integer(1, 1000))
                .executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    int kills = net.minecraft.commands.arguments.IntegerArgumentType.getInteger(ctx, "kills");
                    QuestProgress.start(player, kills);
                    ctx.getSource().sendSuccess(() -> Component.literal("Квест начат: победите " + kills + " мобов."), false);
                    return 1;
                })))
            .then(Commands.literal("dialogue").then(Commands.argument("text", net.minecraft.commands.arguments.StringArgumentType.greedyString())
                .requires(s -> s.hasPermission(2))
                .executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    String text = net.minecraft.commands.arguments.StringArgumentType.getString(ctx, "text");
                    Villager nearest = player.serverLevel().getEntitiesOfClass(Villager.class,
                        player.getBoundingBox().inflate(8), v -> v.hasCustomName()).stream()
                        .min((a,b) -> Double.compare(a.distanceToSqr(player), b.distanceToSqr(player))).orElse(null);
                    if (nearest == null) {
                        ctx.getSource().sendFailure(Component.literal("Рядом нет именованного NPC."));
                        return 0;
                    }
                    nearest.getPersistentData().putString("questnpc_dialogue", text);
                    player.sendSystemMessage(Component.literal("§6" + nearest.getName().getString() + ": §f" + text));
                    return 1;
                }))));
    }

    @SubscribeEvent
    public void onNpcInteract(PlayerInteractEvent.EntityInteract event) {
        if (event.getLevel().isClientSide) return;
        if (event.getTarget() instanceof Villager villager && villager.hasCustomName()) {
            Player player = event.getEntity();
            String dialogue = villager.getPersistentData().getString("questnpc_dialogue");
            if (dialogue.isBlank()) dialogue = "Привет, путник! У меня есть для тебя задание.";
            player.sendSystemMessage(Component.literal("§6[" + villager.getName().getString() + "] §f" + dialogue));
            player.sendSystemMessage(Component.literal("§eЧтобы взять квест, используй /questnpc quest 5"));
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    @SubscribeEvent
    public void onMobDeath(LivingDeathEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) return;
        QuestProgress.onKill(player);
    }
}
