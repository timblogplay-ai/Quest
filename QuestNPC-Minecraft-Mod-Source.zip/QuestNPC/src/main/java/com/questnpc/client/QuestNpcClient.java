package com.questnpc.client;

import com.questnpc.QuestNpcMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.settings.KeyMapping;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = QuestNpcMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class QuestNpcClient {
    public static KeyMapping OPEN_MENU;
    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        OPEN_MENU = new KeyMapping("key.questnpc.menu", GLFW.GLFW_KEY_O, "key.categories.questnpc");
        event.register(OPEN_MENU);
    }

    @Mod.EventBusSubscriber(modid = QuestNpcMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ClientEvents {
        @SubscribeEvent
        public static void renderHud(RenderGuiEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) return;
            // HUD is intentionally a lightweight tracker panel; active quest status is announced server-side.
            // Full persistent synced progress is a follow-up networking enhancement.
        }

        @SubscribeEvent
        public static void clientTick(net.minecraftforge.event.TickEvent.ClientTickEvent event) {
            if (event.phase != net.minecraftforge.event.TickEvent.Phase.END || OPEN_MENU == null) return;
            Minecraft mc = Minecraft.getInstance();
            while (OPEN_MENU.consumeClick()) {
                if (mc.player != null) mc.player.displayClientMessage(Component.literal("§6QuestNPC §7| §fРедактор: используйте предмет NPC Editor или /questnpc help"), false);
            }
        }
    }
}
