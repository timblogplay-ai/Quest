package com.questnpc;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class QuestProgress {
    private static final Map<UUID, State> ACTIVE = new ConcurrentHashMap<>();
    private QuestProgress() {}

    public static void start(ServerPlayer player, int target) {
        ACTIVE.put(player.getUUID(), new State(target, 0));
        player.sendSystemMessage(Component.literal("§aКвест принят! Прогресс: 0%"));
    }

    public static void onKill(ServerPlayer player) {
        State state = ACTIVE.get(player.getUUID());
        if (state == null || state.done >= state.target) return;
        state.done++;
        int percent = Math.min(100, state.done * 100 / state.target);
        player.sendSystemMessage(Component.literal("§6Квест: §f" + state.done + "/" + state.target + " (§e" + percent + "%§f)"));
        if (state.done >= state.target) {
            ACTIVE.remove(player.getUUID());
            player.sendSystemMessage(Component.literal("§aКвест выполнен! Награда: 3 изумруда."));
            player.getInventory().add(net.minecraft.world.item.Items.EMERALD.getDefaultInstance());
            player.getInventory().add(net.minecraft.world.item.Items.EMERALD.getDefaultInstance());
            player.getInventory().add(net.minecraft.world.item.Items.EMERALD.getDefaultInstance());
        }
    }

    public static int getPercent(ServerPlayer player) {
        State state = ACTIVE.get(player.getUUID());
        return state == null ? -1 : Math.min(100, state.done * 100 / state.target);
    }

    private static final class State {
        final int target;
        volatile int done;
        State(int target, int done) { this.target = target; this.done = done; }
    }
}
